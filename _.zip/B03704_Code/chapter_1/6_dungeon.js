function Dungeon(cells) {
  this.freeCells = cells
}

var dungeon = new Dungeon(100)
dungeon.freeCells -= 5
dungeon.freeCells += 3



