configurator.engineConstraints = [ 
  new Contstraint(BodyTypes.CONVERTIBLE, Engines.V8, Engines.V6_6L) 
]
