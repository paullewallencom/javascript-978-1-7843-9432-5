var transportManager = new TransportManager(driver, horse, cart)
transportManager.initializeTransport(prisoner)
