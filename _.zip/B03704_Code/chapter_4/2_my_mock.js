var myMock = {
  called: false,
  aFunction: function () { myMock.called = true }
}