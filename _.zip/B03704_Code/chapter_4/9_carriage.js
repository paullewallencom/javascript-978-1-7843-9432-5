var carriage = {
  transport: function(prisoner) { 
    // do some work
  }
}

carriage.transport(aPrisoner)